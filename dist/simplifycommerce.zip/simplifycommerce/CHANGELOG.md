#Change Log

##v1.2.0
- Adding "Australia" in the supported countries list

##v1.1.0
- Fix the card on file not working for subscription payment

##v1.0.0
- First version