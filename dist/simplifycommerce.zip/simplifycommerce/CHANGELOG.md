# Change Log

## v1.3.0
- Save hosted payment for subscription

## v1.2.0
- Adding "Australia" to the supported countries list
- Pass currency code in Hosted Payments args


## v1.1.0
- Fix the card on file not working for subscription payment

## v1.0.0
- First version