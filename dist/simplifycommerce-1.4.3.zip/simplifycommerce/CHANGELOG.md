# Change Log

## v1.4.3
- Fix issue with amounts off by 1c.

## v1.4.2
- Adding Qatar to the supported countries list

## v1.4.1
- Using hash_equals in return_handler helps prevent timing attacks.

## v1.4.0
- Display supported card types set by merchant

## v1.3.0
- Save hosted payment for subscription

## v1.2.0
- Adding "Australia" to the supported countries list
- Pass currency code in Hosted Payments args

## v1.1.0
- Fix the card on file not working for subscription payment

## v1.0.0
- First version
